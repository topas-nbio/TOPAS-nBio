//#define DEBUG_DAMARIS
//#define PLOT_MOTION
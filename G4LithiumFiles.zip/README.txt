1. Put G4DNAExcitation.cc and G4DNAIonisation.cc in
   geant4-v11.1.3/source/processes/electromagnetic/dna/processes/src/

2. Put G4DNAGenericIonsManager.cc in
   geant4-v11.1.3/source/processes/electromagnetic/dna/utils/src/

3. Build/Rebuild Geant4

